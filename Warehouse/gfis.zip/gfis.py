import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression

# --------------------------------------------------
# Page Config
# --------------------------------------------------
st.set_page_config(
    page_title="GFIS – GreenFuel Intelligence System",
    layout="wide"
)

st.title("🌱 GreenFuel Intelligence System (GFIS)")
st.subheader("AI-driven Biogas Planning for Solapur & Nearby Towns")

# --------------------------------------------------
# Load Dataset
# --------------------------------------------------
@st.cache_data
def load_data():
    df = pd.read_csv("solapur_gfis_dataset.csv")
    df = df.drop_duplicates()
    df = df.fillna(df.select_dtypes(include=np.number).mean())
    return df

df = load_data()

# --------------------------------------------------
# Sidebar
# --------------------------------------------------
st.sidebar.header("⚙️ GFIS Controls")

clusters = st.sidebar.slider(
    "Select number of AI clusters",
    min_value=2,
    max_value=8,
    value=5
)

# --------------------------------------------------
# KPIs
# --------------------------------------------------
st.markdown("### 📊 Key Statistics")

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Records", len(df))
col2.metric("Total Waste (TPD)", round(df["total_waste_tpd"].sum(), 2))
col3.metric("Total Biogas (m³/day)", round(df["estimated_biogas_m3_day"].sum(), 2))
col4.metric("Avg Methane %", round(df["estimated_methane_pct"].mean(), 2))

# --------------------------------------------------
# Clustering (GFIS Core)
# --------------------------------------------------
st.markdown("### 🗺️ AI-Based Biogas Hub Clustering")

features = df[
    [
        "latitude",
        "longitude",
        "organic_waste_tpd",
        "animal_waste_tpd",
        "total_waste_tpd"
    ]
]

scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

kmeans = KMeans(n_clusters=clusters, random_state=42)
df["ai_cluster"] = kmeans.fit_predict(scaled_features)

# --------------------------------------------------
# Map Visualization
# --------------------------------------------------
map_df = df[["latitude", "longitude", "ai_cluster"]].copy()
map_df.rename(columns={"latitude": "lat", "longitude": "lon"}, inplace=True)

st.map(map_df)

# --------------------------------------------------
# ML Prediction – Biogas
# --------------------------------------------------
st.markdown("### 🤖 Biogas Production Prediction")

X = df[
    [
        "organic_waste_tpd",
        "animal_waste_tpd",
        "total_waste_tpd",
        "collection_efficiency_pct",
        "digester_capacity_tpd"
    ]
]

y = df["estimated_biogas_m3_day"]

model = LinearRegression()
model.fit(X, y)

# User input
st.markdown("#### 🔢 Enter Input Values")

c1, c2, c3 = st.columns(3)

organic = c1.number_input("Organic Waste (TPD)", 0.0, 100.0, 10.0)
animal = c2.number_input("Animal Waste (TPD)", 0.0, 100.0, 5.0)
eff = c3.slider("Collection Efficiency (%)", 50, 100, 80)

c4, c5 = st.columns(2)
total = c4.number_input("Total Waste (TPD)", 0.0, 150.0, organic + animal)
digester = c5.number_input("Digester Capacity (TPD)", 1.0, 100.0, 20.0)

if st.button("🔍 Predict"):
    input_data = np.array([[organic, animal, total, eff, digester]])
    biogas_pred = model.predict(input_data)[0]
    electricity = biogas_pred * 2.0

    st.success(f"Estimated Biogas: {biogas_pred:.2f} m³/day")
    st.success(f"Electricity Potential: {electricity:.2f} kWh/day")

# --------------------------------------------------
# CO2 Reduction
# --------------------------------------------------
st.markdown("### 🌍 Environmental Impact")

df["co2_reduction"] = (
    df["estimated_biogas_m3_day"] * 2.0 * 0.82 / 1000
)

st.metric(
    "Estimated CO₂ Reduction (tonnes/year)",
    round(df["co2_reduction"].sum(), 2)
)

# --------------------------------------------------
# Download
# --------------------------------------------------
st.markdown("### ⬇️ Download Processed Data")

csv = df.to_csv(index=False).encode("utf-8")

st.download_button(
    "Download GFIS Output CSV",
    csv,
    "gfis_processed_output.csv",
    "text/csv"
)
