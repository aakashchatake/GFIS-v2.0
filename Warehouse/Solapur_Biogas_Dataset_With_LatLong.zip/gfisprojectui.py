# gfis_ui.py
import streamlit as st
import pandas as pd
import numpy as np

from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

import plotly.express as px
import joblib
import io

# ---------------------------
# Helpers
# ---------------------------
@st.cache_data
def load_data(path_or_buffer=None):
    if path_or_buffer is None:
        df = pd.read_csv("Solapur_Biogas_Dataset_With_LatLong.csv")
    else:
        df = pd.read_csv(path_or_buffer)
    return df

@st.cache_data
def train_kmeans(X, n_clusters):
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    kmeans.fit(X)
    return kmeans

@st.cache_data
def train_regression(X, y):
    model = LinearRegression()
    model.fit(X, y)
    return model

def prepare_features(df):
    df = df.copy()

    ward_encoder = LabelEncoder()
    feed_encoder = LabelEncoder()

    df["Ward_enc"] = ward_encoder.fit_transform(df["Ward"])
    df["Feedstock_enc"] = feed_encoder.fit_transform(df["Feedstock_Type"])

    features = [
        "Ward_enc",
        "Human_Population",
        "Animal_Population",
        "Avg_Transport_Distance_km",
        "Feedstock_enc",
        "Feed_Rate_kg_hr",
        "Digester_Temp_C",
        "pH",
        "CH4_percent",
        "C_N_Ratio"
    ]

    return df[features], ward_encoder, feed_encoder

# ---------------------------
# App Layout
# ---------------------------
st.set_page_config(page_title="GFIS – Solapur Biogas UI", layout="wide")
st.title("GFIS — Solapur Biogas Intelligence System")

# Sidebar
st.sidebar.header("Data Input")
uploaded_file = st.sidebar.file_uploader("Upload CSV (optional)", type=["csv"])
use_default = st.sidebar.checkbox("Use default Solapur dataset", value=(uploaded_file is None))

if uploaded_file is not None and not use_default:
    df = load_data(uploaded_file)
else:
    df = load_data(None)

st.sidebar.markdown(f"Rows: **{len(df):,}**")

# Preview
with st.expander("Preview Dataset"):
    st.dataframe(df.head(200))

# ---------------------------
# Summary Metrics
# ---------------------------
col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Total Wards", df["Ward"].nunique())
with col2:
    st.metric("Avg Gas Flow (m³/hr)", f"{df['Gas_Flow_m3_hr'].mean():.2f}")
with col3:
    st.metric("Avg CO₂e Reduction (kg/hr)", f"{df['CO2e_Reduction_kg_hr'].mean():.2f}")

# ---------------------------
# Clustering (Ward-level hubs)
# ---------------------------
st.subheader("K-Means Clustering (Biogas Hub Planning)")

cluster_df = df.groupby("Ward").agg({
    "Human_Population": "mean",
    "Animal_Population": "mean",
    "Avg_Transport_Distance_km": "mean"
}).reset_index()

n_clusters = st.slider("Number of clusters", 2, 6, 3)

if st.button("Run Clustering"):
    X_cluster = cluster_df[[
        "Human_Population",
        "Animal_Population",
        "Avg_Transport_Distance_km"
    ]]
    kmeans = train_kmeans(X_cluster, n_clusters)
    cluster_df["Cluster"] = kmeans.labels_

    st.success("Clustering completed")
    st.dataframe(cluster_df)

    fig = px.scatter(
        cluster_df,
        x="Human_Population",
        y="Animal_Population",
        color="Cluster",
        size="Avg_Transport_Distance_km",
        hover_name="Ward",
        title="Ward-level Biogas Hub Clustering"
    )
    st.plotly_chart(fig, use_container_width=True)

# ---------------------------
# Regression Model Training
# ---------------------------
st.subheader("Train Regression Model (Gas Flow Prediction)")

if st.button("Train Model"):
    X, ward_enc, feed_enc = prepare_features(df)
    y = df["Gas_Flow_m3_hr"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = train_regression(X_train, y_train)
    y_pred = model.predict(X_test)

    st.write(f"MAE: {mean_absolute_error(y_test, y_pred):.3f}")
    st.write(f"R² Score: {r2_score(y_test, y_pred):.3f}")

    joblib.dump(model, "gfis_solapur_gasflow_model.joblib")
    joblib.dump(ward_enc, "ward_encoder.joblib")
    joblib.dump(feed_enc, "feedstock_encoder.joblib")

    fig2 = px.scatter(
        x=y_test,
        y=y_pred,
        labels={"x": "Actual Gas Flow", "y": "Predicted Gas Flow"},
        title="Actual vs Predicted Gas Flow"
    )
    st.plotly_chart(fig2, use_container_width=True)

    st.success("Model trained and saved")

# ---------------------------
# Prediction Form
# ---------------------------
st.subheader("Predict Gas Flow for New Input")

with st.form("predict_form"):
    ward = st.selectbox("Ward", df["Ward"].unique())
    feedstock = st.selectbox("Feedstock Type", df["Feedstock_Type"].unique())

    human_pop = st.number_input("Human Population", value=150000)
    animal_pop = st.number_input("Animal Population", value=30000)
    dist = st.number_input("Transport Distance (km)", value=5.0)
    feed_rate = st.number_input("Feed Rate (kg/hr)", value=480)
    temp = st.number_input("Digester Temperature (°C)", value=38.0)
    ph = st.number_input("pH", value=7.1)
    ch4 = st.number_input("Methane %", value=61.0)
    cn = st.number_input("C:N Ratio", value=26.0)

    submit = st.form_submit_button("Predict")

    if submit:
        model = joblib.load("gfis_solapur_gasflow_model.joblib")
        ward_enc = joblib.load("ward_encoder.joblib")
        feed_enc = joblib.load("feedstock_encoder.joblib")

        input_df = pd.DataFrame([[
            ward_enc.transform([ward])[0],
            human_pop,
            animal_pop,
            dist,
            feed_enc.transform([feedstock])[0],
            feed_rate,
            temp,
            ph,
            ch4,
            cn
        ]], columns=[
            "Ward_enc",
            "Human_Population",
            "Animal_Population",
            "Avg_Transport_Distance_km",
            "Feedstock_enc",
            "Feed_Rate_kg_hr",
            "Digester_Temp_C",
            "pH",
            "CH4_percent",
            "C_N_Ratio"
        ])

        pred = model.predict(input_df)[0]
        st.success(f"Predicted Gas Flow: {pred:.2f} m³/hr")

# ---------------------------
# Download Dataset
# ---------------------------
st.sidebar.markdown("---")
st.sidebar.header("Downloads")

csv_buffer = io.BytesIO()
df.to_csv(csv_buffer, index=False)
st.sidebar.download_button(
    "Download Dataset CSV",
    data=csv_buffer.getvalue(),
    file_name="Solapur_Biogas_Dataset_Used.csv",
    mime="text/csv"
)

st.sidebar.markdown("GFIS • Solapur Module")