# gfis_ui.py
import streamlit as st
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
import plotly.express as px
import joblib
import io

# ---------------------------
# Helpers
# ---------------------------
@st.cache_data
def load_data(path_or_buffer=None):
    if path_or_buffer is None:
        # Default dataset path (update this if your CSV is elsewhere)
        path_or_buffer = "/mnt/data/gfis_biogas_dataset.csv"
        df = pd.read_csv(r"C:\Users\ANUSHKA\OneDrive\Desktop\ml\gfis_biogas_dataset.csv")

    return df

@st.cache_data
def train_kmeans(coords, n_clusters, random_state=42):
    k = KMeans(n_clusters=n_clusters, random_state=random_state)
    k.fit(coords)
    return k

@st.cache_data
def train_regression(X, y):
    model = LinearRegression()
    model.fit(X, y)
    return model

def prepare_features(df):
    le = LabelEncoder()
    df = df.copy()
    if 'waste_type' in df.columns:
        df['waste_type_encoded'] = le.fit_transform(df['waste_type'])
    else:
        df['waste_type_encoded'] = 0
    features = ['daily_waste_mass_kg', 'animal_population',
                'population_density', 'distance_to_road_km',
                'waste_type_encoded']
    X = df[features]
    return X, le

# ---------------------------
# App layout
# ---------------------------
st.set_page_config(page_title="GFIS - Biogas UI", layout="wide")
st.title("GFIS — Biogas Dataset Explorer & UI")

# Sidebar: data upload / options
st.sidebar.header("Data Input")
uploaded_file = st.sidebar.file_uploader("Upload CSV (optional)", type=["csv"])
use_default = st.sidebar.checkbox("Use default sample dataset", value=(uploaded_file is None))

if uploaded_file is not None and not use_default:
    df = load_data(uploaded_file)
else:
    df = load_data(None)

st.sidebar.markdown(f"Dataset rows: **{len(df):,}**")

# Main: show data
with st.expander("Preview dataset"):
    st.dataframe(df.head(200))

# Quick Summary
col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Locations", len(df))
with col2:
    st.metric("Avg daily waste (kg)", f"{df['daily_waste_mass_kg'].mean():.2f}")
with col3:
    st.metric("Avg methane yield (m3)", f"{df['methane_yield_m3'].mean():.2f}")

# Map visualization
st.subheader("Map: Locations")
if 'latitude' in df.columns and 'longitude' in df.columns:
    map_df = df[['latitude', 'longitude']].rename(columns={'latitude':'lat','longitude':'lon'})
    st.map(map_df)
else:
    st.info("Dataset has no latitude/longitude columns to map.")

# K-Means clustering UI
st.subheader("K-Means Clustering (Location Hubs)")
n_clusters = st.slider("Number of clusters", min_value=2, max_value=12, value=5)
if 'latitude' in df.columns and 'longitude' in df.columns:
    coords = df[['latitude', 'longitude']]
    if st.button("Run K-Means"):
        kmeans = train_kmeans(coords, n_clusters)
        df['cluster'] = kmeans.labels_.astype(int)
        st.success("K-Means clustering complete.")
        # Show cluster centers
        centers = pd.DataFrame(kmeans.cluster_centers_, columns=['latitude', 'longitude'])
        st.write("Cluster centers:")
        st.dataframe(centers)
        # Plot clusters with Plotly
        fig = px.scatter(df, x='longitude', y='latitude', color='cluster',
                         hover_data=['location_id', 'daily_waste_mass_kg', 'methane_yield_m3'],
                         title="K-Means Clustering of Locations")
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)
else:
    st.info("Latitude and longitude required for clustering.")

# Regression training for methane yield
st.subheader("Train Regression Model (Methane Yield Prediction)")
if st.button("Train Regression Model"):
    # Prepare features
    X, le = prepare_features(df)
    y = df['methane_yield_m3']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
    model = train_regression(X_train, y_train)
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    st.write(f"MAE: {mae:.4f}")
    st.write(f"R²: {r2:.4f}")
    # Save model and encoder
    joblib.dump(model, "gfis_methane_model.joblib")
    joblib.dump(le, "gfis_label_encoder.joblib")
    st.success("Model trained and saved as `gfis_methane_model.joblib`")

    # Show Actual vs Predicted plot
    fig2 = px.scatter(x=y_test, y=y_pred,
                      labels={'x':'Actual methane (m3)','y':'Predicted methane (m3)'},
                      title="Actual vs Predicted Methane")
    st.plotly_chart(fig2, use_container_width=True)

# Prediction form
st.subheader("Predict Methane Yield for a Custom Location")
with st.form("predict_form"):
    mass = st.number_input("Daily waste mass (kg)", min_value=0.0, value=500.0)
    animals = st.number_input("Animal population", min_value=0, value=50)
    pop_den = st.number_input("Population density", min_value=0, value=300)
    dist_road = st.number_input("Distance to road (km)", min_value=0.0, value=3.0)

    waste_type = st.selectbox(
        "Waste type",
        options=df['waste_type'].unique() if 'waste_type' in df.columns
        else ["cattle_dung", "food_waste", "mixed_bio_waste"]
    )

    submit = st.form_submit_button("Predict")

    if submit:
        # Load saved model if exists, otherwise train
        try:
            model = joblib.load("gfis_methane_model.joblib")
            le = joblib.load("gfis_label_encoder.joblib")
        except Exception:
            X_all, le = prepare_features(df)
            y_all = df['methane_yield_m3']
            model = train_regression(X_all, y_all)

        # Encode waste type
        try:
            wt_enc = le.transform([waste_type])[0]
        except Exception:
            wt_enc = 0

        X_new = pd.DataFrame([{
            'daily_waste_mass_kg': mass,
            'animal_population': animals,
            'population_density': pop_den,
            'distance_to_road_km': dist_road,
            'waste_type_encoded': wt_enc
        }])

        pred = model.predict(X_new)[0]
        st.success(f"Predicted methane yield: {pred:.2f} m³ per day")

# Download dataset
st.sidebar.markdown("---")
st.sidebar.header("Downloads")
csv_buffer = io.BytesIO()
df.to_csv(csv_buffer, index=False)
csv_bytes = csv_buffer.getvalue()
st.sidebar.download_button("Download current dataset CSV",
                            data=csv_bytes,
                            file_name="gfis_biogas_dataset_used.csv",
                            mime="text/csv")

st.sidebar.markdown("App by GFIS • Example UI for clustering & regression")
